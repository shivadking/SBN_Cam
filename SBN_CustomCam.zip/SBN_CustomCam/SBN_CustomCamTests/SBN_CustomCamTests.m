//
//  SBN_CustomCamTests.m
//  SBN_CustomCamTests
//
//  Created by Mini Mac i72 on 2/28/14.
//  Copyright (c) 2014 Mini Mac i72. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface SBN_CustomCamTests : XCTestCase

@end

@implementation SBN_CustomCamTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
