//
//  ViewController.h
// //

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)btnCapture:(id)sender;
@end
