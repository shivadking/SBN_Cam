//
//  imgController.h
////

#import <UIKit/UIKit.h>

@interface imgController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *imgView;
- (IBAction)btnBack:(id)sender;
@property (strong, nonatomic) UIImage *imgaes;
@end
